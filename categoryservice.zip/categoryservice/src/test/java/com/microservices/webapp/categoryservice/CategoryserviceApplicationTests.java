package com.microservices.webapp.categoryservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CategoryserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
