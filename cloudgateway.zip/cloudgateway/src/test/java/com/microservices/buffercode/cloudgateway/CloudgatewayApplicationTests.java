package com.microservices.buffercode.cloudgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudgatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
