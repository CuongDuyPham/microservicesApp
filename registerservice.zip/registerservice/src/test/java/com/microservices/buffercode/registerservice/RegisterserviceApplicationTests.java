package com.microservices.buffercode.registerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegisterserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
